#include <ESP8266WiFi.h>
#include <Wire.h>
#include <LiquidCrystal_I2C.h>

// ESP8266 NodeMCU — servidor TCP; Arduino ESP8266 core 3.x.
const char* AP_SSID = "ESP8266_Server";
const char* AP_PASS = "12345678"; // Solo laboratorio; cambiar en despliegue.
const IPAddress AP_IP(192, 168, 4, 1);
const IPAddress AP_GW(192, 168, 4, 1);
const IPAddress AP_MASK(255, 255, 255, 0);
constexpr uint16_t PORT = 80;
constexpr uint8_t RELAY_PIN = D1;  // GPIO5
constexpr uint8_t SDA_PIN = D2;    // GPIO4
constexpr uint8_t SCL_PIN = D3;    // GPIO0: comprobar nivel HIGH al arrancar
constexpr uint8_t RELAY_ON = LOW;
constexpr uint8_t RELAY_OFF = HIGH;
constexpr uint32_t WELCOME_MS = 3000;
constexpr uint32_t LINK_STALE_MS = 12000;
constexpr uint32_t CLIENT_IDLE_MS = 1200;
constexpr size_t MAX_LINE = 40;

WiFiServer server(PORT);
LiquidCrystal_I2C lcd(0x27, 16, 2);
WiFiClient activeClient;
char lineBuf[MAX_LINE + 1];
size_t lineLen = 0;
bool lineOverflow = false;
bool relayOn = false;
bool seenValid = false;
uint32_t lastValidMs = 0;
uint32_t lastByteMs = 0;
uint32_t welcomeUntil = 0;
char objectName[9] = "NINGUNO";
char prevTop[17] = "";
char prevBottom[17] = "";
uint32_t commandsReceived = 0;
uint32_t clientsReceived = 0;

void setRelay(bool on) {
  relayOn = on;
  digitalWrite(RELAY_PIN, on ? RELAY_ON : RELAY_OFF);
}

void lcdLine(uint8_t row, const char* source, char* previous) {
  char next[17];
  snprintf(next, sizeof(next), "%-16.16s", source);
  if (strcmp(next, previous) == 0) return;
  lcd.setCursor(0, row);
  lcd.print(next);
  strcpy(previous, next);
}

void updateLCD() {
  if ((int32_t)(millis() - welcomeUntil) < 0) return;
  bool connectedRecently = seenValid && (uint32_t)(millis() - lastValidMs) <= LINK_STALE_MS;
  char top[17], bottom[17];
  snprintf(top, sizeof(top), "CNT:%s LED:%s", connectedRecently ? "OK" : "--", relayOn ? "OFF" : "ON");
  snprintf(bottom, sizeof(bottom), "OBJ: %s", objectName);
  lcdLine(0, top, prevTop);
  lcdLine(1, bottom, prevBottom);
}

bool validObject(const char* obj) {
  return strcmp(obj,"PERSONA")==0 || strcmp(obj,"TAZA")==0 ||
         strcmp(obj,"SILLA")==0 || strcmp(obj,"BOTELLA")==0 ||
         strcmp(obj,"NINGUNO")==0;
}

void reply(const char* response) {
  activeClient.print(response);
  activeClient.print('\n');
  activeClient.flush(); // Vaciar escritura saliente; sin espera indefinida de ACK de aplicación.
  Serial.print("[TX] "); Serial.println(response);
}

void processLine(char* cmd) {
  size_t n = strlen(cmd);
  if (n && cmd[n-1] == '\r') cmd[n-1] = '\0';
  Serial.print("[RX] "); Serial.println(cmd);
  const char* response = "ERR:CMD";
  bool valid = false;
  if (strcmp(cmd, "PING") == 0) { response = "ACK:PING"; valid = true; }
  else if (strcmp(cmd, "LED ON") == 0) { setRelay(true); response = "ACK:LED ON"; valid = true; }
  else if (strcmp(cmd, "LED OFF") == 0) { setRelay(false); response = "ACK:LED OFF"; valid = true; }
  else if (strcmp(cmd, "STATUS") == 0) { response = relayOn ? "STATUS:ON" : "STATUS:OFF"; valid = true; }
  else if (strncmp(cmd, "OBJ:", 4) == 0 && validObject(cmd + 4)) {
    strncpy(objectName, cmd + 4, sizeof(objectName)-1);
    objectName[sizeof(objectName)-1] = '\0';
    response = "ACK:OBJ"; valid = true;
  }
  if (valid) { seenValid = true; lastValidMs = millis(); commandsReceived++; }
  reply(response);
  updateLCD();
  // Un comando por conexión: el cliente lee una línea y cierra.
  activeClient.stop();
}

void resetClient() {
  if (activeClient) activeClient.stop();
  lineLen = 0;
  lineOverflow = false;
}

void serviceTCP() {
  // Rechazar clientes extra mientras hay una sesión activa.
  WiFiClient candidate = server.accept();
  if (candidate) {
    if (activeClient && activeClient.connected()) {
      candidate.println("ERR:BUSY");
      candidate.stop();
    } else {
      resetClient();
      activeClient = candidate;
      activeClient.setNoDelay(true);
      lastByteMs = millis();
      clientsReceived++;
      Serial.printf("[TCP] Cliente #%lu IP=%s\n", (unsigned long)clientsReceived,
                    activeClient.remoteIP().toString().c_str());
    }
  }
  if (!activeClient) return;
  uint8_t budget = 64; // Acotar trabajo de red por vuelta.
  while (budget-- && activeClient.available()) {
    char ch = (char)activeClient.read();
    lastByteMs = millis();
    if (ch == '\n') {
      if (lineOverflow) reply("ERR:LONG");
      else {
        lineBuf[lineLen] = '\0';
        processLine(lineBuf);
      }
      resetClient();
      return;
    }
    if (!lineOverflow) {
      if (lineLen < MAX_LINE) lineBuf[lineLen++] = ch;
      else lineOverflow = true;
    }
  }
  if (!activeClient.connected() && !activeClient.available()) {
    resetClient();
  } else if ((uint32_t)(millis() - lastByteMs) > CLIENT_IDLE_MS) {
    Serial.println("[TCP] Cliente inactivo (timeout)");
    resetClient();
  }
}

void setup() {
  // Evita pulso LOW por el firmware al configurar la salida.
  digitalWrite(RELAY_PIN, RELAY_OFF);
  pinMode(RELAY_PIN, OUTPUT);
  setRelay(false);
  Serial.begin(115200);
  Serial.println();
  Serial.println("=== ESP8266 SERVIDOR TCP ===");
  Serial.print("[BOOT] reset reason: "); Serial.println(ESP.getResetReason());
  Wire.begin(SDA_PIN, SCL_PIN);
  Wire.setClock(100000);
  lcd.init();
  lcd.backlight();
  lcdLine(0, "BIENVENIDO", prevTop);
  lcdLine(1, "GAFAS INTELIG.", prevBottom);
  welcomeUntil = millis() + WELCOME_MS;

  WiFi.persistent(false);
  WiFi.mode(WIFI_AP);
  WiFi.softAPConfig(AP_IP, AP_GW, AP_MASK);
  bool ok = WiFi.softAP(AP_SSID, AP_PASS);
  Serial.printf("[AP] %s, IP=%s\n", ok ? "OK" : "ERROR", WiFi.softAPIP().toString().c_str());
  server.begin();
  server.setNoDelay(true);
  Serial.printf("[TCP] Puerto %u escuchando\n", PORT);
}

void loop() {
  serviceTCP();
  if (relayOn && seenValid && (uint32_t)(millis() - lastValidMs) > LINK_STALE_MS) {
    Serial.println("[SAFE] Sin comandos validos >12 s: apagando rele");
    setRelay(false);
  }
  updateLCD();
  static uint32_t lastDiag = 0;
  if (millis() - lastDiag >= 10000) {
    lastDiag = millis();
    Serial.printf("[ESTADO] estaciones=%u relay=%s cmds=%lu heap=%lu\n",
      WiFi.softAPgetStationNum(), relayOn ? "ON" : "OFF",
      (unsigned long)commandsReceived, (unsigned long)ESP.getFreeHeap());
  }
  yield();
}
