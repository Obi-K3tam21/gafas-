#include <WiFi.h>
#include <esp_system.h>
#include <HardwareSerial.h>

// ESP32-CAM AI Thinker — cliente TCP y pruebas de aplicación sin cámara.
const char* SSID = "ESP8266_Server";
const char* PASS = "12345678";
const IPAddress SERVER_IP(192, 168, 4, 1);
constexpr uint16_t SERVER_PORT = 80;
constexpr uint32_t WIFI_WAIT_MS = 20000;
constexpr uint32_t WIFI_RETRY_MS = 15000;
constexpr uint32_t TCP_TIMEOUT_MS = 1200;
constexpr uint32_t REPLY_TIMEOUT_MS = 1200;
constexpr uint32_t PING_INTERVAL_MS = 5000;
constexpr uint32_t PAUSA_ENTRE_CICLOS_MS = 10000; // 10 segundos entre diagnósticos
constexpr uint8_t MAX_TRIES = 3;
constexpr size_t MAX_RESPONSE = 40;


// HW-311 (protocolo serial compatible con familia DFPlayer).
// Conexiones: GPIO13 (TX ESP32) -> RX modulo; GPIO14 (RX ESP32) <- TX modulo.
// Alimentar el reproductor de acuerdo con su placa, compartir GND.
// GPIO13/14 comparten funciones con microSD de ESP32-CAM: NO usar SD_MMC a la vez.
constexpr int AUDIO_TX_PIN = 13;
constexpr int AUDIO_RX_PIN = 14;
constexpr uint32_t AUDIO_BAUD = 9600;
constexpr uint8_t AUDIO_VOLUME = 28; // 0..30
constexpr uint32_t AUDIO_BOOT_WAIT_MS = 1500;
constexpr uint32_t AUDIO_CMD_GAP_MS = 150;
HardwareSerial hw311(1);
uint8_t audioSetupStep = 0;
uint8_t pendingTrack = 0;
uint32_t audioLastCommandMs = 0;
uint32_t audioStartMs = 0;

// Trama: 7E FF 06 CMD 00 PARAM_H PARAM_L CHECK_H CHECK_L EF
void sendAudioFrame(uint8_t cmd, uint16_t param) {
  uint8_t hi = (uint8_t)(param >> 8), lo = (uint8_t)param;
  uint16_t checksum = (uint16_t)(0 - (0xFF + 0x06 + cmd + hi + lo));
  const uint8_t frame[10] = {0x7E, 0xFF, 0x06, cmd, 0x00, hi, lo,
                             (uint8_t)(checksum >> 8), (uint8_t)checksum, 0xEF};
  hw311.write(frame, sizeof(frame));
  audioLastCommandMs = millis();
}

void beginAudio() {
  hw311.begin(AUDIO_BAUD, SERIAL_8N1, AUDIO_RX_PIN, AUDIO_TX_PIN);
  audioStartMs = millis();
  Serial.println("[AUDIO] HW-311: comandos 1..9 por monitor serial (115200)");
  Serial.println("[AUDIO] Archivos: /mp3/0001.mp3 ... /mp3/0009.mp3");
}

void readSerialCommands() {
  // '1' a '9' funciona con o sin ajuste de fin de linea.
  while (Serial.available()) {
    char c = (char)Serial.read();
    if (c >= '1' && c <= '9') {
      pendingTrack = (uint8_t)(c - '0');
      Serial.printf("[AUDIO] Solicitada pista %u\n", pendingTrack);
    }
  }
}

void serviceAudio() {
  uint32_t now = millis();
  if (now - audioStartMs < AUDIO_BOOT_WAIT_MS) return;
  if (audioSetupStep != 0 && now - audioLastCommandMs < AUDIO_CMD_GAP_MS) return;
  if (audioSetupStep == 0) {
    sendAudioFrame(0x09, 0x0002); // Seleccionar tarjeta TF/microSD
    audioSetupStep = 1;
    Serial.println("[AUDIO] Seleccionando microSD");
    return;
  }
  if (audioSetupStep == 1) {
    sendAudioFrame(0x06, AUDIO_VOLUME);
    audioSetupStep = 2;
    Serial.printf("[AUDIO] Volumen=%u/30\n", AUDIO_VOLUME);
    return;
  }
  if (pendingTrack) {
    uint8_t track = pendingTrack;
    pendingTrack = 0;
    sendAudioFrame(0x12, track); // Reproduce /mp3/000N.mp3
    Serial.printf("[AUDIO] Comando de reproduccion enviado: pista %u\n", track);
    // Sin realimentacion: el envio no demuestra que el sonido haya comenzado.
  }
}

uint32_t lastWiFiAttempt = 0;
uint32_t wifiStartMs = 0;
uint32_t lastPingMs = 0;
uint32_t lastCycleFinishMs = 0;
uint32_t cycleNumber = 0;
uint32_t tcpAttempts = 0;
uint32_t reconnectAttempts = 0;
uint32_t totalTimeouts = 0;
uint32_t consecutivePingFailures = 0;
bool wifiWasConnected = false;
bool diagnosticDone = false;
bool diagnosticStarted = false;
bool wifiOK = false, tcpOK = false, pingOK = false, lcdLogicalOK = false, relayLogicalOK = false;
uint8_t step = 0;
uint32_t stepDue = 0;

void beginWiFi() {
  WiFi.mode(WIFI_STA);
  WiFi.setSleep(false); // Diagnóstico: prioriza latencia.
  WiFi.setAutoReconnect(false); // Un solo administrador de reconexión.
  WiFi.begin(SSID, PASS);
  wifiStartMs = millis();
  lastWiFiAttempt = millis();
  Serial.println("[WIFI] Inicio de asociación...");
}

void checkWiFi() {
  bool connected = WiFi.status() == WL_CONNECTED;
  if (connected && !wifiWasConnected) {
    wifiWasConnected = true;
    Serial.printf("[WIFI] Conectado. IP=%s GW=%s RSSI=%d dBm\n",
      WiFi.localIP().toString().c_str(), WiFi.gatewayIP().toString().c_str(), WiFi.RSSI());
    wifiOK = true;
    diagnosticDone = false;
    diagnosticStarted = false;
    step = 0;
    stepDue = millis();
  }
  if (!connected && wifiWasConnected) {
    wifiWasConnected = false;
    Serial.println("[ERROR] Wi-Fi perdido; se reiniciará el diagnóstico al recuperar enlace");
    diagnosticDone = false;
    diagnosticStarted = false;
    wifiOK = false;
    tcpOK = false;
    pingOK = false;
  }
  if (!connected && (uint32_t)(millis() - lastWiFiAttempt) >= WIFI_RETRY_MS &&
      (uint32_t)(millis() - wifiStartMs) >= WIFI_WAIT_MS) {
    // Reconnect sobre la configuración existente; nunca repetir begin durante asociación.
    Serial.printf("[WIFI] Reintento reconexión #%lu, estado=%d\n",
      (unsigned long)++reconnectAttempts, (int)WiFi.status());
    WiFi.reconnect();
    lastWiFiAttempt = millis();
    wifiStartMs = millis();
  }
}

// Una transacción TCP por comando. Límite de tamaño y de tiempo de respuesta.
bool exchangeOnce(const char* command, const char* expected, char* received, size_t cap) {
  received[0] = '\0';
  WiFiClient client;
  client.setNoDelay(true);
  client.setTimeout(REPLY_TIMEOUT_MS);
  uint32_t start = millis();
  ++tcpAttempts;
  if (!client.connect(SERVER_IP, SERVER_PORT, TCP_TIMEOUT_MS)) {
    Serial.printf("[TCP] Falló connect, intento global=%lu, %lu ms\n",
      (unsigned long)tcpAttempts, (unsigned long)(millis()-start));
    return false;
  }
  tcpOK = true;
  Serial.printf("[TX] %s\n", command);
  if (client.print(command) != strlen(command) || client.print('\n') != 1) {
    Serial.println("[ERROR] Escritura TCP incompleta");
    client.stop();
    return false;
  }
  size_t len = 0;
  bool tooLong = false;
  uint32_t responseStart = millis();
  bool complete = false;
  while ((uint32_t)(millis() - responseStart) < REPLY_TIMEOUT_MS) {
    while (client.available()) {
      char c = (char)client.read();
      if (c == '\n') { complete = true; break; }
      if (c == '\r') continue;
      if (len + 1 < cap) received[len++] = c;
      else tooLong = true;
    }
    if (complete || tooLong) break;
    if (!client.connected() && !client.available()) break;
    delay(1); // Ceder CPU, espera acotada únicamente en transacción.
  }
  received[len] = '\0';
  client.stop();
  uint32_t latency = millis() - start;
  Serial.printf("[RX] %s | %lu ms\n", received, (unsigned long)latency);
  if (tooLong || !complete) {
    totalTimeouts++;
    Serial.println(tooLong ? "[ERROR] Respuesta excesiva" : "[ERROR] Respuesta incompleta/timeout");
    return false;
  }
  bool match = strcmp(received, expected) == 0;
  if (!match) Serial.printf("[ERROR] Esperado: %s\n", expected);
  return match;
}

bool command(const char* outgoing, const char* expected) {
  if (WiFi.status() != WL_CONNECTED) return false;
  char response[MAX_RESPONSE + 1];
  for (uint8_t i = 1; i <= MAX_TRIES; ++i) {
    Serial.printf("[INTENTO] %s (%u/%u)\n", outgoing, i, MAX_TRIES);
    if (exchangeOnce(outgoing, expected, response, sizeof(response))) return true;
    if (WiFi.status() != WL_CONNECTED) break;
    if (i < MAX_TRIES) delay(50);
  }
  return false;
}

void printReport() {
  Serial.println("\n========================");
  Serial.println("RESULTADO DEL DIAGNOSTICO");
  Serial.println("========================");
  Serial.printf("WIFI:        %s\n", wifiOK ? "OK" : "ERROR");
  Serial.printf("TCP:         %s\n", tcpOK ? "OK" : "ERROR");
  Serial.printf("LCD:         %s*\n", lcdLogicalOK ? "OK" : "ERROR");
  Serial.printf("RELAY:       %s*\n", relayLogicalOK ? "OK" : "ERROR");
  Serial.printf("PING:        %s\n", pingOK ? "OK" : "ERROR");
  Serial.printf("TCP intentos: %lu | timeouts: %lu | reconexiones WiFi: %lu\n",
    (unsigned long)tcpAttempts, (unsigned long)totalTimeouts, (unsigned long)reconnectAttempts);
  Serial.println("* Requiere comprobación física independiente");
  Serial.println("========================\n");
}

void runDiagnostic() {
  if (WiFi.status() != WL_CONNECTED || diagnosticDone) return;
  if ((int32_t)(millis() - stepDue) < 0) return;
  if (!diagnosticStarted) {
    diagnosticStarted = true;
    Serial.printf("\n=== INICIO DIAGNOSTICO - CICLO %lu ===\n", (unsigned long)++cycleNumber);
    wifiOK = true; tcpOK = false; pingOK = false;
    lcdLogicalOK = true; relayLogicalOK = true;
    step = 0;
  }
  // Los cambios de pantalla se espacian 2 segundos. Si falla un comando,
  // la ejecución sigue para acumular resultados, sin dejar relé ON al final.
  switch (step) {
    case 0:
      Serial.printf("[1] WiFi OK IP=%s RSSI=%d dBm\n", WiFi.localIP().toString().c_str(), WiFi.RSSI());
      Serial.println("[2-3] TCP + PING");
      pingOK = command("PING", "ACK:PING");
      stepDue = millis();
      break;
    case 1: lcdLogicalOK &= command("OBJ:PERSONA", "ACK:OBJ"); stepDue = millis() + 2000; break;
    case 2: lcdLogicalOK &= command("OBJ:TAZA", "ACK:OBJ"); stepDue = millis() + 2000; break;
    case 3: lcdLogicalOK &= command("OBJ:SILLA", "ACK:OBJ"); stepDue = millis() + 2000; break;
    case 4: lcdLogicalOK &= command("OBJ:BOTELLA", "ACK:OBJ"); stepDue = millis() + 2000; break;
    case 5: lcdLogicalOK &= command("OBJ:NINGUNO", "ACK:OBJ"); stepDue = millis() + 2000; break;
    case 6: relayLogicalOK &= command("LED ON", "ACK:LED ON"); stepDue = millis() + 2000; break; // 2 s visible
    case 7: relayLogicalOK &= command("STATUS", "STATUS:ON"); stepDue = millis() + 150; break;
    case 8: relayLogicalOK &= command("LED OFF", "ACK:LED OFF"); stepDue = millis() + 150; break;
    case 9: relayLogicalOK &= command("STATUS", "STATUS:OFF"); stepDue = millis(); break;
    case 10: lcdLogicalOK &= command("OBJ:NINGUNO", "ACK:OBJ"); stepDue = millis(); break;
    case 11:
      // Limpieza final aun cuando algún comando anterior haya fallado.
      relayLogicalOK &= command("LED OFF", "ACK:LED OFF");
      printReport();
      diagnosticDone = true;
      lastCycleFinishMs = millis();
      lastPingMs = millis();
      Serial.printf("[CICLO %lu] Finalizado. Próximo en %lu s.\n",
        (unsigned long)cycleNumber, (unsigned long)(PAUSA_ENTRE_CICLOS_MS / 1000));
      return;
  }
  ++step;
}

void setup() {
  Serial.begin(115200);
  Serial.println("\n=== ESP32-CAM CLIENTE TCP ===");
  Serial.printf("[BOOT] esp_reset_reason=%d | heap libre=%lu\n",
    (int)esp_reset_reason(), (unsigned long)ESP.getFreeHeap());
  beginAudio();
  beginWiFi();
}

void loop() {
  readSerialCommands();
  serviceAudio();
  checkWiFi();
  runDiagnostic();
  if (diagnosticDone && WiFi.status() == WL_CONNECTED &&
      (uint32_t)(millis() - lastPingMs) >= PING_INTERVAL_MS) {
    lastPingMs = millis();
    bool ok = command("PING", "ACK:PING");
    if (ok) consecutivePingFailures = 0;
    else ++consecutivePingFailures;
    Serial.printf("[MONITOR] %s RSSI=%d dBm fallosConsecutivos=%lu\n",
      ok ? "PING OK" : "PING ERROR", WiFi.RSSI(),
      (unsigned long)consecutivePingFailures);
  }
  // Durante la pausa continúa la supervisión PING; luego se repite el diagnóstico.
  if (diagnosticDone && WiFi.status() == WL_CONNECTED &&
      (uint32_t)(millis() - lastCycleFinishMs) >= PAUSA_ENTRE_CICLOS_MS) {
    diagnosticDone = false;
    diagnosticStarted = false;
    step = 0;
    stepDue = millis();
    Serial.println("[LOOP] Reiniciando secuencia de pruebas...");
  }
  delay(1);
}
